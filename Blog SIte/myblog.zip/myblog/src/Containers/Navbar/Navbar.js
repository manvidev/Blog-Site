
import { NavLink } from "react-router-dom";
import "./Navbar.css";

const links = [
  { name: "Home", url: "/" },
  { name: "About", url: "/about" },
  { name: "Posts", url: "/posts" },
  { name: "Login", url: "/login" },
  { name: "Signin", url: "/signin" },
  { name: "Blog", url: "/blog" },
  { url: "/readblog" },
  { url: "/contactus" },
]

export const Navbar=()=> {
  return (
    <div className="row">
    <div className="topnav">
          {links.map((e, index) => {
            return (
              <NavLink className='navtab' key={index} to={e.url}> {e.name}
              </NavLink>
            )
          })}
      </div>
      </div>
  );
}