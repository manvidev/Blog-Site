import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import{App} from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter } from 'react-router-dom';
import {store} from './Redux/Store'
import { Provider } from 'react-redux';

// const store = createStore(reducer);
// store.subscribe(()=>console.log(store.getState()))
import { createRoot } from 'react-dom/client';
const container = document.getElementById('root');
const root = createRoot(container);
root.render(
<Provider store={store}>
  <BrowserRouter>
     <App/>
  </BrowserRouter>
    </Provider>
    );

// ReactDOM.render(
//    <Provider store={store}>
//  <BrowserRouter>
//     <App/>
//  </BrowserRouter>
//    </Provider>,
//   document.getElementById('root')
// );

reportWebVitals();

