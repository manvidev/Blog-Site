import { toast } from "react-toastify";
import {
  collection,
  setDoc,
  doc,
  addDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  getDoc,
} from "firebase/firestore";
import {
  onAuthStateChanged,
  getAuth,
  signOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth";
import {
  getStorage,
  ref,
  uploadBytesResumable,
  getDownloadURL,
} from "firebase/storage";
import { auth, db } from "../Firebase";

export const dbref = collection(db, "users");
export const dbRef = collection(db, "blogs");
// export const dbData = collection(db, "contactDetails");
const storage = getStorage();
export const storageRef = ref(storage, "images");
export const storageVideoRef = ref(storage, "videos");

export const createUser = async (email, pass) => {
  try {
    return await createUserWithEmailAndPassword(auth, email, pass);
  } catch (error) {
    toast.error(error.message);
  }
};

export const addData = async (email, username, id) => {
  try {
    await setDoc(doc(dbref, email), {
      username: username,
      email: email,
      uid: id,
    });
  } catch (error) {
    return error.message;
  }
};

export const addBlog = async (titledata, description, imgUrl, videoUrl) => {
  console.log("imgUrl?>????????????",imgUrl)
  console.log("videoUrl?>????????????",videoUrl)

  try {
    return await addDoc(collection(dbRef, "data", "allblogs"), {
      titledata: titledata,
      blogPara: description,
      imgUrl: imgUrl||'',
      videoUrl: videoUrl || '',
      uid: auth.currentUser.uid,
    });
  } catch (error) {
    console.log(error.message);
    return error;
  }
};





export const fetchBlogs = async () => {
  const docRef = doc(collection(db, "blogs"));
  const docSnap = await getDocs(collection(db, "blogs", "data", "allblogs"));
  if (docSnap) {
    console.log("docsnapppppppp", docSnap);
    const blogs = [];
    docSnap.forEach((doc) => {
      let blogdata = doc.data();
      let blogid = doc.id;
      blogs.push({ ...blogdata, blogid });
    });
    return blogs;
  } else {
    console.log("No such document");
  }
};

export const updateBlog = async (id, titledata, description, imgUrl, videoUrl) => {
  const path = doc(dbRef, "data", "allblogs", id);
  console.log(id,"path idddddddddd")
  await updateDoc(path,{
    titledata: titledata,
    blogPara: description,
    imgUrl: imgUrl,
    videoUrl: videoUrl,
  });
};

export const deleteBlog = async (id) => {
  console.log(id,"deleteblogid")
  try {
    const res = await deleteDoc(doc(dbRef, "data", "allblogs", id));
    return res;
  } catch (error) {
    console.log(error.message);
  }
};


// export const addContactDetails = async (firstName,lastName , country, subject) => {
//   try {
//     return await addDoc(collection(dbData, "data", "alldetails"), {
//      firstName: firstName,
//      lastName: lastName,
//      country:country,
//      subject:subject,
//       uid: auth.currentUser.uid,
//     });
//   } catch (error) {
//     console.log(error.message);
//     return error;
//   }
// };


export const signInUser = async (email, pass) => {
  try {
    let response = await signInWithEmailAndPassword(auth, email, pass);
    return response;
  } catch (error) {
    toast.error(error.message);
  }
};

export const addUser = async (email, pass) => {
  try {
    const res = await setDoc(doc(dbref, email), {
      email: email,
      pass: pass,
    });
    return res;
  } catch (error) {
    toast.error(error.message);
  }
};

export const isUserHandle = () => {
  return new Promise((resolve, reject) => {
    const auth = getAuth();
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        const docRef = doc(dbref, auth.currentUser.email);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          resolve(docSnap.data());
          console.log(docRef,"docreffffffff")
        } else {
          reject(null)
        }
      } else {
        reject(null)
      }
    })
  })
};

export const logout = async () => {
  try {
    await signOut(getAuth());
    toast.success("logout Successfully");
  } catch (error) {
    toast.error(error.message);
  }
};