import blogger1 from './blogger1.jpeg'
import blogger2 from './blogger2.jpg'
import blogger3 from './blogger3.jpg'

export {blogger1,blogger2,blogger3}