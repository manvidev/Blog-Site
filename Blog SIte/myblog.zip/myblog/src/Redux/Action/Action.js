
export const showBlogAction=(DATA)=>{
    return({type:"SHOWBLOGS",data:DATA})
}


// export const imageUrlAction=(DATA)=>{
//     return({type:"SHOWURL",data:DATA})
// }

