
export const showTheBlogs=(state=[],action)=>{
    switch (action.type){
        case "SHOWBLOGS" : return action.data;
        default: return state ;
    }
}

