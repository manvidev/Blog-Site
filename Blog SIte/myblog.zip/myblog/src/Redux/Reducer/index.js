
 import { showTheBlogs,} from './Reducer'
 import {combineReducers} from 'redux'
 
 export const rootReducer= combineReducers({
     showTheBlogs,
    
 })
