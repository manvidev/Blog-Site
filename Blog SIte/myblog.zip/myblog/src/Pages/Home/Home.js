

import { useLocation } from "react-router";
import {Header} from "../../Components";
// import Posts from "../../components/posts/Posts";
// import Sidebar from "../../components/sidebar/Sidebar";
import "./Home.css";

export const Home=() =>{
  const location = useLocation();
  console.log(location);
  return (
    <>
      <div className="home">
      <Header />
      </div>
    </>
  );
}





  
