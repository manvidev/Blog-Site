import React, { useState } from "react";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { Button ,InputField} from "../../Components";
import { addData, createUser } from "../../Utill";
import "./Signin.css";

localStorage.setItem("key", "value");

export const Signin = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: { value: "" },
    name: { value: "" },
    pass: { value: "" },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let response = await createUser(
        formData?.email?.value,
        formData?.pass?.value
      );
      let id = response.user.uid;
      console.log(id, "id");
      if (response) {
        console.log(response, "response");
        const res = await addData(
          formData?.email?.value,
          formData?.name?.value,
          id
        );
        window.localStorage.setItem("email", formData?.email?.value);
        window.localStorage.setItem("pass", formData?.pass?.value);
        window.localStorage.setItem("uid", id);
        navigate("/blog");
      } else {
        toast.error("no user");
      }
    } catch (error) {
      toast.error("error");
    }
  };

  const handleChange = (key, e) => {
    const value = e.target.value;
    switch (key) {
      case "name":
        setFormData({
          ...formData,
          [key]: {
            value: value,
          },
        });
        return;
      case "email":
        setFormData({
          ...formData,
          [key]: {
            value: value,
          },
        });
        return;
      case "pass":
        setFormData({
          ...formData,
          [key]: {
            value: value,
          },
        });
    }
  };

  const isbtnDisabled = () => {
    if (
      !formData?.email?.value ||
      !formData?.name?.value ||
      !formData?.pass?.value
    ) {
      return true;
    } else {
      return false;
    }
  };

  return (
    <div className="card">
      <div className="signIn">
        <form className="signInForm" onSubmit={(e) => handleSubmit(e)}>
          <div>
            <h5 style={{ color: "black" }}> Email </h5>
            <InputField
             
              type="email"
              name="email"
              value={formData.email.value}
              handleChange={handleChange}
            />
            <h5> Name </h5>
            <InputField
              type="text"
              name="name"
              value={formData.name.value}
              handleChange={handleChange}
            />
            <h5> Password </h5>
            <InputField
              type="password"
              name="pass"
              value={formData.pass.value}
              handleChange={handleChange}
            />
            <Button
              className="signInButton"
              title="Submit"
              type="submit"
              disabled={isbtnDisabled()}
            />
          </div>
        </form>
      </div>
    </div>
  );
};