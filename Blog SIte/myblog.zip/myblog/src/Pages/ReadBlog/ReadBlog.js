import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { showBlogAction } from "../../Redux/Action/Action";
import { fetchBlogs } from "../../Utill";

export const ReadBlog = () => {
  const { id } = useParams();
  console.log(id, "useparams Idddddddddd");
  const blogs = useSelector((state) =>
    state?.showTheBlogs?.filter((item) => item.blogid == id)
  );
  const [blogData, setBlogData] = useState(blogs);
  const dispatch = useDispatch();

  useEffect(() => {
    getblogdata();
  }, []);

  const getblogdata = async () => {
    try {
      const res = await fetchBlogs();
      dispatch(showBlogAction(res));
      setBlogData(res?.filter((item) => item?.blogid == id));
    } catch (error) {
      console.log("error", error);
    }
  };

  return (
    <>
      {blogData.map((item, i) => {
        return (
          <div key={i} className="card">
            <h1>{item.titledata}</h1>
            {item.imgUrl?  <img
                        src={item.imgUrl}
                        alt=""
                        // width={"500px"}
                        // height={"230px"}
                      />:""}
                       {item.videoUrl? <video width="320" height="240" controls>
                        <source src={item.videoUrl} type="video/mp4"></source>
                      </video> :"" }
            <p dangerouslySetInnerHTML={{ __html: item.blogPara }}></p>
          </div>
        );
      })}
    </>
  );
};
