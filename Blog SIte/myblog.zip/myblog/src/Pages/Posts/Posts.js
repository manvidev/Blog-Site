import { getAuth } from "firebase/auth";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faBookOpen,
  faEdit,
  faTrash,
  faSquareXmark,
} from "@fortawesome/free-solid-svg-icons";
import { SpinnerCircular } from "spinners-react";

import {
  Button,
  ButtonToggle,
  ButtonToolbar,
  OverlayTrigger,
  popover,
  Spinner,
} from "reactstrap";
import { showBlogAction } from "../../Redux/Action/Action";
import { deleteBlog, fetchBlogs } from "../../Utill";
import "./Post.css";

export const Posts = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const myState = useSelector((state) => state.showTheBlogs);
  const auth = getAuth();
  const [user, setUser] = useState(null);
  const [isOpen, setIsopen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    auth.onAuthStateChanged(() => {
      setUser(auth?.currentUser);
    });
  });

  const getmyState = async () => {
    try {
      const res = await fetchBlogs();
      console.log(res, "fetchblog res");
      dispatch(showBlogAction(res));
      return res;
    } catch (error) {
      console.log("error", error);
    }
  };

  const deleteTheBlog = async (id) => {
    try {
      await deleteBlog(id);
      getmyState();
    } catch (error) {
      console.log(error.message);
    }
  };

  const ToggleSidebar = () => {
    // alert('11')
    isOpen === true ? setIsopen(false) : setIsopen(true);
    // setIsopen(!isOpen)
  };

  useEffect(() => {
    getmyState();
  }, []);

  return (
    <>
      <div className="main">
        {myState &&
          myState.map((item, index) => {
            return (
              <>
                <div className="card">
                  <h4>
                    A blog is only as interesting as the interest shown in
                    others. – Lee Odden
                  </h4>
                </div>
                <div class="row">
                  <div class="leftcolumn">
                    <div class="card">
                      <div>
                        <h2>{item.titledata}</h2>

                        {item.imgUrl ? (
                          <img
                            src={item.imgUrl}
                            alt=""
                            width={"100%"}
                            height={"100%"}
                          />
                        ) : (
                          ""
                        )}

                        {item.videoUrl ? (
                          <video width={"100%"} height={"100%"} controls>
                            <source
                              src={item.videoUrl}
                              type="video/mp4"
                            ></source>
                          </video>
                        ) : (
                          ""
                        )}
                      </div>
                      <p
                        dangerouslySetInnerHTML={{ __html: item.blogPara }}
                      ></p>
                    </div>
                  </div>
                </div>

                <Button className="btn btn-primary" onClick={ToggleSidebar}>
                  click{" "}
                </Button>
                <div className={`sidebar ${isOpen == true ? "active" : ""}`}>
                 
                    <ButtonToolbar>
                      <FontAwesomeIcon
                        icon={faSquareXmark}
                        onClick={ToggleSidebar}
                      />
                    </ButtonToolbar>
                    <div className="btn-body">
                      <button>
                        <FontAwesomeIcon
                          className="icon"
                          icon={faBookOpen}
                          onClick={() => navigate(`/readblog/${item?.blogid}`)}
                        />
                      </button>
                      {auth?.currentUser?.uid == item?.uid && (
                        <button>
                          <FontAwesomeIcon
                            icon={faEdit}
                            onClick={() => navigate(`/blog/${item?.blogid}`)}
                          />
                        </button>
                      )}
                      <button>
                        <FontAwesomeIcon
                          icon={faTrash}
                          onClick={() => deleteTheBlog(item?.blogid)}
                        />
                      </button>
                    </div>
                
                </div>
              </>
            );
          })}
      </div>
      <div className="footer">
        <h2>Footer</h2>
      </div>
    </>
  );
};
