
import React, { useState } from "react";
import {  useNavigate } from "react-router";
import { toast } from "react-toastify";
import { Button, InputField  } from '../../Components';
import { signInUser } from '../../Utill';
import './Login.css'

export const Login = () => {

  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    email: { value: "", },
    pass: { value: "", },
  });

  const handleChange = (key, e) => {
    const value = e.target.value;
    if (key === "email") {
      setFormData({
        ...formData,
        email: {
          value: value,
        },
      });
    }
    else if (key === "pass") {
      setFormData({
        ...formData,
        pass: {
          value: value,
        },
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await signInUser(
        formData.email.value,
        formData.pass.value
      );
      console.log(response,"????????????????????response")
      if (response) {
        navigate('/')
        toast.success("login successfully");
        console.log("login successfully")
      }
    } catch (error) {
      toast.error('error')
    }
  };

  const isbtnDisabled = () => {
    if (
      !formData.email.value ||
      !formData.pass.value 
    ) {
      return true;
    } else {
      return false;
    }
  };

  return (
    <center>
      <div className='card'>
      <div className='login'>
      <h1> Login </h1>
      <form className='loginForm' onSubmit={(e) => handleSubmit(e)}>
        <h5> Email </h5>
        <InputField
        className='loginInput'
          type="text"
          name="email"
          value={formData.email.value}
          handleChange={handleChange} />

        <h5> Password </h5>
        <InputField
         className='loginInput'
          type="password"
          name="pass"
          value={formData.pass.value}
          handleChange={handleChange} />

        <Button
        className="loginButton"
          title="login"
          type="submit"
          disabled={isbtnDisabled()} />
      </form>
      </div>
      </div>
    </center>
  );
};