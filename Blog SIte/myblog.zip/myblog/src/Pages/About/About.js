import{ React,useEffect,useState} from "react";
import { useNavigate } from "react-router-dom";
import "./About.css";
import { blogger1,blogger2,blogger3 } from "../../Assets/Images";
import { isUserHandle, logout } from "../../Utill";
import { toast } from "react-toastify";
import { async } from "@firebase/util";

export const About = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState("");

  const contactUs = () => {
    navigate("/contactus");
  };

const logOut=async()=>{
  try {
    await logout();
      toast.success('logout successfully')
      navigate('/login')
  } catch (error) {
    console.log(error)
  }
}


 

  return (
    <>
   
      <div className="about-section">
        <h1>About Us Page</h1>
        <p>Here is about page of our blog site .</p>
        <div className="row">
          <div className="column">
            <div className="card">
              <div className="container">
                <h2>Jane Doe</h2>
               <div>
                  <img src={blogger1} alt="remote" width={'100%'}/>
               </div>
                <p className="title">CEO & Founder</p>
                <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                <p>jane@example.com</p>
                <p>
                  <button className="button" onClick={contactUs}>
                    Contact
                  </button>
                </p>
              </div>
            </div>
          </div>

          <div className="column">
            <div className="card">
              <div className="container">
                <h2>Mike Ross</h2>
                <div>
                <img src={blogger2} alt="pic" width={"100%"}/>
                </div>
                <p className="title">Art Director</p>
                <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                <p>mike@example.com</p>
                <p>
                  <button className="button" onClick={contactUs}>
                    Contact
                  </button>
                </p>
              </div>
            </div>
          </div>

          <div className="column">
            <div className="card">
              <div className="container">
                <h2>John Doe</h2>
                <div className="container">

                <img src={blogger3} alt='remote' width={'100%'}/>
                </div>
                <p className="title">Designer</p>
                <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                <p>john@example.com</p>
                <p>
                  <button className="button" onClick={contactUs}>
                    Contact
                  </button>
                </p>
              </div>
            </div>
          </div>
        </div>
        <button onClick={logOut}>Logout</button>
      </div>
    </>
  );
};