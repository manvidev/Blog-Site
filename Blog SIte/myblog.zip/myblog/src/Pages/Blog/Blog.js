import React, { useEffect, useState,} from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import { getDownloadURL, getStorage, ref, uploadBytesResumable,} from "firebase/storage";
import { showBlogAction } from "../../Redux/Action";
import RichEditor from "../../Components/Editor/RichEditor";
import { addBlog, fetchBlogs, isUserHandle, updateBlog } from "../../Utill";
import "./Blog.css";

const storage = getStorage();
export const storageRef = ref(storage, "images");
export const storageref = ref(storage, "videos");

export const Blog = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const blogs = useSelector((state) => state.showTheBlogs);
  const selectedblog = blogs?.filter((item) => item?.blogid == id);
  const [titledata, setTitleData] = useState("");
  const [description, setDescription] = useState("");
  const [imgUrl, setImgUrl] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [isImg, setIsImg] = useState(true);
  const [process, setProcess] = useState(0);


  const getblogdata = async () => {
    try {
      const res = await fetchBlogs();
      dispatch(showBlogAction(res));
    } catch (error) {
      toast.error("not fetching data");
    }
  };

  const updatedTheBlog = async (id) => {
    try {
      const res = await updateBlog(
        id,
        titledata,
        description,
        imgUrl,
        videoUrl
      );
      if(res){
        toast.success("updated successfully")
      }else{
        toast.error('not update')
      }
    } catch (error) {
      console.log(error.message);
    }
  };

  const addImage = async (file) => {
    if (!file) return;
    const storageRef = ref(storage, `image/${file.name}`);
    const uploadTask = uploadBytesResumable(storageRef, file);
    uploadTask.on(
      "state_changed",
      (snapshot) => {
        const progress =
          Math.round(snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log("Upload is " + progress + "% done");
        setProcess(progress);
      },
      (error) => {
        console.log(error.message);
      },
      async () => {
        await getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
          console.log("image available at", downloadURL);
          setImgUrl(downloadURL);
        });
      }
    );
  };

  const addVideo = async (file) => {
    if (!file) return;
    const storageref = ref(storage, `video/${file.name}`);
    const uploadTask = uploadBytesResumable(storageref, file);
    uploadTask.on(
      "state_changed",
      (snapshot) => {
        const progress =
          Math.round(snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log("Upload is " + progress + "% done");
        setProcess(progress);
      },
      (error) => {
        console.log(error.message);
      },
      async () => {
        await getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
          console.log("Vedio available at", downloadURL);
          setVideoUrl(downloadURL);
        });
      }
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (id) {
      updatedTheBlog(id);
      navigate("/posts");
    } else {
      const response = await addBlog(
        titledata,
        description,
        imgUrl,
        videoUrl,
        id
      );
      if (response) {
        navigate("/posts");
        toast.success("added successfully");
      } else {
        toast.error("error: not added");
      }
    }
  };

  const handleChange = (e) => {
    e.preventDefault();
    setTitleData(e.target?.value);
  };

  const imageHandler = async (e) => {
    e.preventDefault();
    const file = await e.target[0]?.files[0];
    addImage(file);
  };

  const videoHandler = async (e) => {
    e.preventDefault();
    const file = await e.target[0]?.files[0];
    addVideo(file);
  };

  useEffect(() => {
    getblogdata();
  }, []);

  useEffect(() => {
    updatedTheBlog();
  }, [id]);

  useEffect(() => {
    setTitleData(selectedblog[0]?.titledata);
    setDescription(selectedblog[0]?.blogPara);
    setImgUrl(selectedblog[0]?.imgUrl);
    setVideoUrl(selectedblog[0]?.videoUrl);
  }, [id]);

  
  return (
    <>
      {
        <>
          <div className="card">
        
            <div className="container">
              <button onClick={() => setIsImg(true)}>img</button>
              <button onClick={() => setIsImg(false)}>video</button>
              <form onSubmit={isImg ? imageHandler : videoHandler}>
                {isImg? (
                  <>
                    <label>pic</label>
                    <input type="file" accept="image/x-png,image/jpeg,application/pdf"/>
                   {id?<img src={imgUrl} alt='image' width={"200px"} height={"200px"}/>:""}
                  </>
                ) : (
                  <>
                    <label>video</label>
                    <input type="file" accept="video/mp4,video/x-m4v,video/*" />
                    {id?<video src={videoUrl}alt='video' width={"200px"} height={"200px"} ></video>:""} 
                  </>
                )}
                <button type="submit"> Upload {process}% </button>
              </form>
            </div>

            <div className="form-title">
              <form onSubmit={handleSubmit}>
                <div className="card">
                  <input
                    name="title"
                    placeholder="Title"
                    value={titledata}
                    onChange={handleChange}
                    type="text"
                  />
                </div>
                <div className="card">
                  <RichEditor
                    description={description}
                    setDescription={setDescription}
                  />
                </div>
                <button className="writeSubmit" type="submit">
                  {id ? "Update" : "Publish"}
                </button>
              </form>
            </div>
          </div>
        </>
      }
    </>
  );
};