import {React,useEffect,useState} from 'react'
// import { Navigate } from 'react-router'
import { useNavigate , Navigate } from "react-router-dom";
import {getAuth} from 'firebase/auth';

import "firebase/firestore"

export const PrivateRoute = ({Component}) => {
    const navigate  = useNavigate();

  const auth = getAuth();
    const [user, setUser] = useState(null);

    useEffect(()=>{
        auth.onAuthStateChanged(()=> {
            setUser(auth.currentUser);
        })
    }, []);
  
return auth.currentUser ? <Component/> :<Navigate to="/login"/>
    
}