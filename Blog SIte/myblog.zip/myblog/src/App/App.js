import React from "react";
import { Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Navbar } from "../Containers";
import {
  Home,
  About,
  Blog,
  Login,
  Signin,
  ReadBlog,
  Posts,
  Edit,
  Contact,
} from "../Pages";
import { PrivateRoutes } from "../Routing";
import "./App.css";
export const App = () => {
  return (
    <>
      <ToastContainer />
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<PrivateRoutes Component={About} />} />
        {/* <Route path="/about" element={<About/>} /> */}
        <Route path="/posts" element={<Posts />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signin" element={<Signin />} />
        <Route path="/blog/:id" element={<Blog />} />
        <Route path="/blog" element={<PrivateRoutes Component={Blog} />} />
        <Route path="/readBlog/:id" element={<ReadBlog />} />
        <Route path="/contactus" element={<Contact />} />
      </Routes>
    </>
  );
};
