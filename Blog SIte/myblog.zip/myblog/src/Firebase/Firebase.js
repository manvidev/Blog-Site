
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from 'firebase/firestore';
import "firebase/firestore"

const firebaseConfig =initializeApp({
  apiKey: "AIzaSyBXTbQPpKr8L_rDIac7qVTchDwdM2lOQbA",
  authDomain: "blog-f66fe.firebaseapp.com",
  projectId: "blog-f66fe",
  storageBucket: "blog-f66fe.appspot.com",
  messagingSenderId: "591313032905",
  appId: "1:591313032905:web:2cf6f913c92c8be9131f18"
}) ;

export const db = getFirestore(firebaseConfig);
export const auth = getAuth();
export default firebaseConfig;