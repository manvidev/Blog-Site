import React from 'react'

export const Button = (props) => {
    const {
        className,
        type,
        onSubmit,
        onClick,
        disabled,
        title } = props;
    
      return (
        <button
          className={className}
          type={type}
          onSubmit={onSubmit}
          disabled={disabled}
          onClick={onClick}>
          {title}
        </button>
      );
}
