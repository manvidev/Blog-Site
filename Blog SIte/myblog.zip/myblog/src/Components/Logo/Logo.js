// import React from 'react'
// import './Logo.css'

// export const Logo = () => {
//   return (
//     <div className='logo'>
//        <h1>
//            Blog Logo
//            </h1>  
//     </div>
//   )
// }
