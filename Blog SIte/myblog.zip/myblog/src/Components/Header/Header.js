import {React,useEffect,useState }from "react";
import { toast } from "react-toastify";
import { isUserHandle } from "../../Utill";
import "./Header.css";

export const Header = () => {
  const [user, setUser] = useState("")

  useEffect(() => {
  
    isUserHandle()
      .then((res) => {
        setUser(res.username)
        console.log(res.username,)
      }).catch(error => {
        toast.error("error")
        // (handleErrors(error))
      })
  }, []);

  return (
    <div className="container">
    <div className="card">
      <div className="header">
        <div className="headerTitles">
          <span className="headerTitleSm">React & Node</span>
          <span className="headerTitleLg">BLOG</span>
        </div>
        <img
          className="headerImg"
          src="https://images.pexels.com/photos/1167355/pexels-photo-1167355.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
          alt=""
        />
      </div>
    </div>
    </div>
  );
};
