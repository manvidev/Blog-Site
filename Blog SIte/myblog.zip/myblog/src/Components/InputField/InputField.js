import { TextField } from '@mui/material';
import React from 'react'

export const InputField = (props) => {
  return (
        <>
          <TextField variant='standard'
            type={props.type}
            name={props.name}
            value={props.value}
            onChange={(e) => {
              props.handleChange(props.name, e)
            }} />
          <span style={{ color: "red" }}>
            <p> {props.errorMessage} </p>
          </span>
          <br />
        </>
      );
}