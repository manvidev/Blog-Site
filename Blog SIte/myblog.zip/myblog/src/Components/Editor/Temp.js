import React, { useState } from "react";
import RichEditor from "./RichEditor";

/**
 * @author
 * @function Temp
 **/

export const Temp = (props) => {
  const [description, setDescription] = useState("");
  return (
    <>
  
      <RichEditor description={description} setDescription={setDescription} />
     data : {description}
  
    </>
  );
};